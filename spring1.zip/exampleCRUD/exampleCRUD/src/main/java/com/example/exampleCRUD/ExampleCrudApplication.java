package com.example.exampleCRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleCrudApplication.class, args);
	}

}
