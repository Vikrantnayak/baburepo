package com.example.exampleCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
